import React from 'react';

const Footer = () => {
    return (
        <>
            <footer id="footer">
                <div className="container">
                  
                </div>
            </footer>
        </>
    );
};

export default Footer;