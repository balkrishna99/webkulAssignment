import { Outlet, Link } from "react-router-dom";
// import { Dropdown } from 'react-bootstrap';
import NavDropdown from "react-bootstrap/NavDropdown";
import { useDispatch, useSelector } from "react-redux";
import { toggleCart } from "../Redux/cartSlice";

const NavBar = () => {
  const { cartItems } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const handleOpenCart = (open) => {
    dispatch(toggleCart(open));
  };

  const cartQuantity = cartItems.length;

  return (
    <>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <div className="font_bold">
            <h3>Shopping Cart </h3>
          </div>

          {/* <div className="carticon">
            <img
              src="https://cdn-icons-png.flaticon.com/128/3144/3144456.png"
              alt="Carticon"
            />
          </div> */}

<div
                                title="Cart"
                                className="cart_icon"
                                onClick={() => handleOpenCart(true)}
                            >
                                <img src="https://cdn-icons-png.flaticon.com/128/3144/3144456.png" alt="bag-icon" />
                                <span className="badge">{cartQuantity}</span>
                            </div>

          <NavDropdown title="Click Me " id="basic-nav-dropdown">
            <NavDropdown.Item href="#">
              {" "}
              <li>
                <Link to="/">Login</Link>
              </li>{" "}
            </NavDropdown.Item>
            <NavDropdown.Item href="#">
              <li>
                <Link to="/signup">Register</Link>
              </li>
            </NavDropdown.Item>
          </NavDropdown>

          <ul class="navbar-nav">
            <li>
              <Link to="/ProductDetails">ProductDetails</Link>
            </li>
          </ul>
        </div>
      </nav>

      <Outlet />
    </>
  );
};

export default NavBar;
