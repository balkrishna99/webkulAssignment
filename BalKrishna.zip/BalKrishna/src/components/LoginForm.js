import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const LoginForm = () => {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState("");

  const [emailError, setEmailError] = useState();
  const [passwordError, setPasswordError] = useState();
  // const[NameError , setNameError] = useState();
  const navigate= useNavigate()

  const validateForm = () => {
    let isValid = true;

    if (!email) {
      setEmailError("Please enter your email address");
      isValid = false;
    } else {
      setEmailError("");
    }

    if (!password) {
      setPasswordError("Please enter your password");
      isValid = false;
    } else {
      setPasswordError("");
    }

    return isValid;
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    validateForm();
    localStorage.setItem("email", email);
  };
  //   console.log("emailError", emailError);

  function check() {
    var storedName = localStorage.getItem("email");
    var storedPw = localStorage.getItem("password");
    var emailget = localStorage.getItem("name");

    var userName = document.getElementById("form2Example1");
    var userPw = document.getElementById("form2Example2");
    // var userRemember = document.getElementById("rememberMe");

    if (userName.value === storedName && userPw.value === storedPw) {
      alert("You are logged in as " + emailget);
      navigate('/ProductDetails')

    } else {
      alert("User Is not Registered");
    }
  }

  return (
    <>
      <div className="container">
        <form onSubmit={(event) => handleSubmit(event)}>
          <section>
            <h1>Login</h1>
            <div className="form-outline mb-4">
              <input
                type="email"
                id="form2Example1"
                className="form-control"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <br />
              <label
                className="form-label"
                style={{ color: "red" }}
                for="form2Example1"
              >
                {emailError}
              </label>

              <div className="form-outline mb-4">
                <input
                  type="password"
                  id="form2Example2"
                  className="form-control"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <br />

                <label
                  className="form-label"
                  for="form2Example2"
                  style={{ color: "red" }}
                >
                  {passwordError}
                </label>
              </div>

              <button
                type="submit"
                className="btn btn-primary btn-block mb-4"
                onClick={check}
              >
                Sign in
              </button>

              <div className="row mb-4">
                <div className="col d-flex justify-content-center">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="form2Example31"
                      checked
                    />
                    <label className="form-check-label" for="form2Example31">
                      {" "}
                      Remember me{" "}
                    </label>
                  </div>
                </div>

                <div className="col">
                  <a href="#!">Forgot password?</a>
                </div>
              </div>

              <div className="text-center">
                <p>If you are not registered then</p>
                <Link to="/signup">Go To SignUp</Link>
              </div>
            </div>
          </section>
        </form>
      </div>
    </>
  );
};

export default LoginForm;
