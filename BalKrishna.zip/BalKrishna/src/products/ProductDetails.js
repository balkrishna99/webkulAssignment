import React from "react";
import { useEffect, useState } from "react";
import { addItem } from "../Redux/cartSlice";
import { useDispatch } from "react-redux";
// import axios from "axios";

const ProductDetails = () => {
  const [data, setData] = useState([]);
const dispatch =useDispatch()
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("https://fakestoreapi.com/products");

        if (response.ok) {
          const jsonData = await response.json();
          setData(jsonData);
        } else {
          console.log("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error("Error in fetching data:", error);
      }
    };
    fetchData();
  }, []);

  console.log("data", data);
  return (
    <>

    
      <div className="container">
      <div class="card">
        <div className="row">
          <div class="col">
          
            <div className="d-flex p-2">
             
              {data ? (
                <ul className="productsRow">
                  {data.map((item) => (
                    <li key={item.id}>
                      <div className="Mens Title">
                    <strong>{item.title}</strong>    
                        </div>
                      <div className="Mens Clothing">
                   <h4>{item.category}</h4>    
                         </div>
                      <div className="Image Products">
                        {
                          <img
                            src={item.image}
                            alt="Store Iamge"
                            style={{ width: "250px", height: "225px" }}
                          />
                        }
                      </div>
                      <div className="ItemPrice">₹ {item.price}</div>
                      <button onClick={()=>dispatch(addItem(item))} className="cartBtn">Add To Cart</button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p>Loading data...</p>
              )}
            </div>
          </div>
        </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetails;
