import LoginForm from "./components/LoginForm";
import SignUp from "./components/SignUp";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import ProductDetails from "./products/ProductDetails";
import Footer from "./components/Footer";
import { Provider } from "react-redux";
import store from "./Redux/store";
import NavBar from "./components/NavBar";

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
      <NavBar />
        <Routes>
            <Route path="/" element={<LoginForm />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/ProductDetails" element={<ProductDetails />} />
        </Routes>
      </BrowserRouter>

      <Footer />
    </Provider>
  );
}

export default App;
